<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <title> Predictions</title>
    </head>
    <body>
    <header class="header" id="home" style=" height: 100px; width: 100%;">
            <div class="nav">
                <div class="navigation container">
                    <div class="logo">
                     <a href="index.php"><h1>BallorTalk</h1></a>
                    </div>
                    <div class="menu">
                        <div class="top-nav">
                            <div class="logo">
                                <h1>BallorTalk</h1>
                            </div>
                            <div class="close">
                                <i class="fa fa-times"></i>
                            </div>
                        </div>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Team</a>
                            </li>
                            <li class="nav-item">
                                <a href="news.php" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="players.php" class="nav-link">Famous Players</a>
                            </li>
                            <li class="nav-item">
                                <a href="tribute.php" class="nav-link">Tribute</a>
                            </li>
                            <li class="nav-item">

                                <a href="index.php" class="nav-link">Contact</a>
                            </li>
                           
                            
                        </ul>
                    </div>
                   
                </div>
            </div>
            <!-- <img src="img/3.png" alt=""> -->
            <!-- <div class="row">
                <div class="col">
                    <img src="img/1.png" alt="">
                </div>
                <div class="col">
                    <img src="img/famous_players_quote.png" alt="">
                </div>
            </div> -->
           

            
           
        </header>

        
            

        <section class="section them"  id="teams">
            <div class="title">
                <h1>Future Predictions</h1>
            </div>
            <div class="team-center container">
                <div class="team" style="background-image: url('img/football.jpeg');">
                   
                    
                    <p style="background-color:black;">
                    1. Lionel Messi
                    <br>
                    <br>
                    Based on Messi's historical performance trends up to 2022, he has consistently been one of the world's top footballers. Known for his goal-scoring prowess, playmaking abilities, and overall impact on the game, Messi has demonstrated remarkable consistency and longevity in his career.
                    <br>
                    Predicting specific future achievements or milestones would be speculative. Factors like which clubs he plays for, his fitness, and the competitiveness of the teams he's associated with will play a crucial role in shaping his future in football.
                    <br>
                    <br>
                    2. Cristiano Ronaldo
                    <br>
                    <br>
                    Cristiano Ronaldo has had a highly successful and consistent career, known for his goal-scoring prowess, athleticism, and dedication to the sport. His impact on the game has been immense, and he has shown the ability to adapt his playing style to maintain a high level of performance as he ages.
                    <br>
                    For the most accurate and current predictions about Cristiano Ronaldo's future performances, it's best to follow the latest news from his current club, interviews with him or his coach, and analysis from football experts. Player performance can be influenced by various factors such as injuries, team dynamics, and personal decisions, so staying updated with the latest information is crucial for accurate predictions.
                    <br>
                    <br>
                    3. Erling Haaland
                    <br>
                    <br>
                    Erling Haaland was considered one of the most promising young talents in world football. Known for his prolific goal-scoring record, physical prowess, and versatility as a striker, he had garnered significant attention from top clubs. His future success would likely depend on factors like his continued development, potential transfers, and the teams he plays for.
                    <br>
                    For the latest and most accurate information on Erling Haaland's current football stats and predictions, we recommend checking recent sports news, official team announcements, and reputable football analysis sources.
                    <br>
                    <br>
                    4. Heung min Son
                    <br>
                    <br>
                    Heung-min Son has been known for his skill, agility, and goal-scoring ability. He is a key player for Tottenham Hotspur and the South Korean national team. His performance can be influenced by various factors such as the team's tactics, the quality of opponents, and his own physical condition.
                    <br>
                    <br>
                    5. Robert Lewandowski
                    <br>
                    <br>
                    Robert Lewandowski is widely regarded as one of the top strikers in the world. He has consistently displayed excellent goal-scoring prowess and is a crucial player for both Bayern Munich and the Polish national team. His performance can be influenced by factors such as the team's tactics, the quality of opponents, and his own physical condition.
                    <br>
                    <br>


                    </p>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        
                    </div>
                </div>
                
            </div>
        </section>
        
       
    </body>
    <script src="js/script.js"></script>
    
</html>