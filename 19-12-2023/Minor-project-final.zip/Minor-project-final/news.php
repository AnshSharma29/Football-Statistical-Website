<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <title>News Section </title>
        <link rel="icon" type="image/x-icon" href="img/4_teams.ico">
    <!-- Google Fonts -->
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap"
      rel="stylesheet"
    />
    <!-- Stylesheet -->
    <link rel="stylesheet" href="css/news.css" />
  </head>
  <body>
    
    <section class="section them" class teams id="teams" style="background-image: url('img/4_teams.jpeg'); ">
      <div class="heading-container">
        <h4 style="color: rgb(235, 130, 11);">Get Latest News Regarding Football</h4>
        <a href="index.php"><button class="btn btn-success">Home</button></a>
      </div>
      <div class="options-container" style="background-color: rgb(22, 21, 21); font:bolder" ></div>
      
      <div class="container" style="background-color: rgb(252, 244, 233);"></div>
  
  </section>
    <!-- API Key -->
    <script src="js/api-key.js"></script>
    <!-- Script -->
    <script src="js/news.js"></script>
  </body>
</html>