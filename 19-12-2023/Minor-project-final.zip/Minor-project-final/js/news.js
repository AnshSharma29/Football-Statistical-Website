//API Used: http://newsapi.org/s/india-news-api


const container = document.querySelector(".container");
const optionsContainer = document.querySelector(".options-container");
// "in" stands for India
const country = ["in","us","uk"];
const options = [

  " View ",
  
];

//100 requests per day
let requestURL;

//Create cards from data
const generateUI = (articles) => {
  for (let item of articles) {
    let card = document.createElement("div");
    card.classList.add("news-card");
    card.innerHTML = `<div class="news-image-container">
    <img src="${item.urlToImage || "./newspaper.jpg"}" alt="" />
    </div>
    <div class="news-content">
      <div class="news-title">
        ${item.title}
      </div>
      <div class="news-description">
      ${item.description || item.content || ""}
      </div>
      <a href="${item.url}" target="_blank" class="view-button">Read More</a>
    </div>`;
    container.appendChild(card);
  }
};

//News API Call
const getNews = async () => {
  container.innerHTML = "";
  let response = await fetch(requestURL);
  if (!response.ok) {
    alert("Data unavailable at this moment. Please try again later");
    return false;
  }
  let data = await response.json();
  generateUI(data.articles);
};

// Category Selection
const selectCategory = (e, category) => {
  let options = document.querySelectorAll(".option");
  options.forEach((element) => {
    element.classList.remove("active");
  });
  // requestURL = `https://newsapi.org/v2/top-headlines?country=${country}&category=${category}&apiKey=${apiKey}`;
  // requestURL=`https://newsapi.org/v2/everything?q=football?country=us&apiKey=c806d341e2334364bdb01af6e48cfdf9`
  // requestURL = `https://newsapi.org/v2/everything?domains=bbc.com&category=football&apiKey=${apiKey}`;
  // requestURL = `https://newsapi.org/v2/top-headlines?country=in&category=football&apiKey=c806d341e2334364bdb01af6e48cfdf9`;
  requestURL = `https://newsapi.org/v2/everything?q=football&apiKey=c806d341e2334364bdb01af6e48cfdf9`;
  e.target.classList.add("active");
  getNews();
};

//Options Buttons
const createOptions = () => {
  for (let i of options) {
    optionsContainer.innerHTML += `<button class="option ${
      i == "general" ? "active" : ""
    }" onclick="selectCategory(event,'${i}')">${i}</button>`;
  }
};

const init = () => {
  optionsContainer.innerHTML = "";
  getNews();
  createOptions();
};

window.onload = () => {
  requestURL = `https://newsapi.org/v2/top-headlines?country=${country}&category=general&apiKey=${apiKey}`;
  init();
};