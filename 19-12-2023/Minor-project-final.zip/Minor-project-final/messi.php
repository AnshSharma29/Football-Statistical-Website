<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <title>Famous Players</title>
    </head>
    <body>
    <header class="header" id="home" style=" height: 100px; width: 100%;">
            <div class="nav">
                <div class="navigation container">
                    <div class="logo">
                     <a href="index.php"><h1>BallorTalk</h1></a>
                    </div>
                    <div class="menu">
                        <div class="top-nav">
                            <div class="logo">
                                <h1>BallorTalk</h1>
                            </div>
                            <div class="close">
                                <i class="fa fa-times"></i>
                            </div>
                        </div>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Team</a>
                            </li>
                            <li class="nav-item">
                                <a href="news.php" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="players.php" class="nav-link">Famous Players</a>
                            </li>
                            <li class="nav-item">
                                <a href="tribute.php" class="nav-link">Tribute</a>
                            </li>
                            <li class="nav-item">

                                <a href="index.php" class="nav-link">Contact</a>
                            </li>
                           
                            <li class="nav-item">
                                <a href="/Minor-project-final/login.php" class="nav-link">Log in</a>
                            </li>
                        </ul>
                    </div>
                   
                </div>
            </div>
            <!-- <img src="img/3.png" alt=""> -->
            <!-- <div class="row">
                <div class="col">
                    <img src="img/1.png" alt="">
                </div>
                <div class="col">
                    <img src="img/famous_players_quote.png" alt="">
                </div>
            </div> -->
           

            
           
        </header>

        
            

        <section class="section them"  id="teams">
            <div class="title">
                <h1>Lionel Messi</h1>
            </div>
            <div class="team-center container">
                <div class="team" style="background-image: url('img/miami.png');">
                    <div class="img-cover">
                        <img src="img/messi.jpeg" alt="Messi">
                    </div>
                    <br>
                    <br>
                    <p style="background-color:black;">
                    
                    Despite his dual citizenship and professional success in Spain, Messi’s ties with his homeland remained strong, and he was a key member of various Argentine national teams from 2005. He played on Argentina’s victorious 2005 FIFA World Youth Championship squad, represented the country in the 2006 World Cup, and scored two goals in five matches as Argentina swept to the gold medal at the Beijing 2008 Olympic Games. Messi helped Argentina reach the 2010 World Cup quarterfinals, where the team was eliminated by Germany for the second consecutive time in World Cup play. At the 2014 World Cup, Messi put on a dazzling display, scoring four goals and almost single-handedly propelling an offense-deficient Argentina team through the group stage and into the knockout rounds, where Argentina then advanced to the World Cup final for the first time in 24 years. Argentina lost that contest 1–0 to Germany, but Messi nevertheless won the Golden Ball award as the tournament’s best player. During the 2016 Copa América Centenario tournament, he netted his 55th international goal to break Gabriel Batistuta’s Argentine scoring record.
                    <br>
                    <br>
                    After Argentina was defeated in the Copa final—the team’s third consecutive finals loss in a major tournament—Messi said that he was quitting the national team, but his short-lived “retirement” lasted less than two months before he announced his return to the Argentine team. At the 2018 World Cup, he helped an overmatched Argentine side reach the knockout stage, where they were eliminated by eventual champion France in their first match. After a third-place finish at the 2019 Copa América, Messi led Argentina to victory in the tournament two years later, and he received the Golden Ball award. His success continued at the 2022 World Cup. There he guided Argentina to the finals, where he scored two goals—and made a penalty kick during the shootout—to help defeat France. Messi won the World Cup’s Golden Ball, becoming the first male player to receive that award twice. In addition, his outstanding play in the tournament was instrumental in Messi winning his eighth Ballon d’Or in 2023.
                        
                    </p>

                    <img src="img/messistats.jpg" alt="Messi Stats">

                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        
                    </div>
                </div>
                
            </div>
        </section>
        
       
    </body>
    <script src="js/script.js"></script>
    
</html>