<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <title>Famous Players</title>
    </head>
    <body>
    <header class="header" id="home" style=" height: 100px; width: 100%;">
            <div class="nav">
                <div class="navigation container">
                    <div class="logo">
                     <a href="index.php"><h1>BallorTalk</h1></a>
                    </div>
                    <div class="menu">
                        <div class="top-nav">
                            <div class="logo">
                                <h1>BallorTalk</h1>
                            </div>
                            <div class="close">
                                <i class="fa fa-times"></i>
                            </div>
                        </div>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Team</a>
                            </li>
                            <li class="nav-item">
                                <a href="news.php" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="players.php" class="nav-link">Famous Players</a>
                            </li>
                            <li class="nav-item">
                                <a href="tribute.php" class="nav-link">Tribute</a>
                            </li>
                            <li class="nav-item">

                                <a href="index.php" class="nav-link">Contact</a>
                            </li>
                           
                            <li class="nav-item">
                                <a href="/Minor-project-final/login.php" class="nav-link">Log in</a>
                            </li>
                        </ul>
                    </div>
                   
                </div>
            </div>
            <!-- <img src="img/3.png" alt=""> -->
            <!-- <div class="row">
                <div class="col">
                    <img src="img/1.png" alt="">
                </div>
                <div class="col">
                    <img src="img/famous_players_quote.png" alt="">
                </div>
            </div> -->
           

            
           
        </header>

        
            

        <section class="section them"  id="teams">
            <div class="title">
                <h1>Sunil Chhetri</h1>
            </div>
            <div class="team-center container">
                <div class="team" style="background-image: url('img/inida.png');">
                    <div class="img-cover">
                        <img src="img/sunil-chettri.jpeg" alt="Chhetri">
                    </div>
                    
                    <p style="background-color:black;">
                    Sunil Chhetri (born 3 August 1984) is an Indian professional footballer who plays as a striker or winger and captains both Indian Super League club Bengaluru FC and the Indian national team . Popularly known as Captain Fantastic , he holds the third position in terms of scoring most goals in international matches among active players after Cristiano Ronaldo and Lionel Messi . He is both the most capped player and list of the country's top international association football goalscorers. All-time top goalscorer for the Indian national team, with 72 national goals in 112 appearances. Sunil Chhetri was named 'Asian Icon' by the AFC on his 34th birthday. 
                    <br>
                    Chhetri started his professional career at Mohun Bagan in 2002. He then moved to JCT where he scored 21 goals in 48 games. He signed for Major League Soccer 's Kansas City Wizards in 2010 , becoming the third player from the subcontinent to move abroad. However, that stint in the United States did not last long and he soon returned to the India I-League , where he played for Chirag United and Mohun Bagan . Before going abroad. This time he was signed by Primeira Liga Sporting Clube de Portugal , where he played for the club's reserve side . 
                    <br>
                    He helped India win the 2007 Nehru Cup , 2009 Nehru Cup , 2012 Nehru Cup as well as the 2011 SAFF Championship . He was one of India's best players during the 2008 AFC Challenge Cup , in which India won the tournament and thus qualified for their first AFC Asian Cup in 27 years. He then led India during their short-lived campaign at the 2011 AFC Asian Cup with two goals . Chhetri has been named All India Football Federation Player of the Year six times , in 2007, 2011, 2013, 2014, 2017 and 2018–19.
                    <br>
                    In 2015, he became the first Indian player to score 50 international goals [
                    </p>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        
                    </div>
                </div>
                
            </div>
        </section>
        
       
    </body>
    <script src="js/script.js"></script>
    
</html>