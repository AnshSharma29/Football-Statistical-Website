<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <title>Famous Players</title>
    </head>
    <body>
    <header class="header" id="home" style=" height: 100px; width: 100%;">
            <div class="nav">
                <div class="navigation container">
                    <div class="logo">
                     <a href="index.php"><h1>BallorTalk</h1></a>
                    </div>
                    <div class="menu">
                        <div class="top-nav">
                            <div class="logo">
                                <h1>BallorTalk</h1>
                            </div>
                            <div class="close">
                                <i class="fa fa-times"></i>
                            </div>
                        </div>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Team</a>
                            </li>
                            <li class="nav-item">
                                <a href="news.php" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="players.php" class="nav-link">Famous Players</a>
                            </li>
                            <li class="nav-item">
                                <a href="tribute.php" class="nav-link">Tribute</a>
                            </li>
                            <li class="nav-item">

                                <a href="index.php" class="nav-link">Contact</a>
                            </li>
                           
                            <li class="nav-item">
                                <a href="/Minor-project-final/login.php" class="nav-link">Log in</a>
                            </li>
                        </ul>
                    </div>
                   
                </div>
            </div>
            <!-- <img src="img/3.png" alt=""> -->
            <!-- <div class="row">
                <div class="col">
                    <img src="img/1.png" alt="">
                </div>
                <div class="col">
                    <img src="img/famous_players_quote.png" alt="">
                </div>
            </div> -->
           

            
           
        </header>

        
            

        <section class="section them"  id="teams">
            <div class="title">
                <h1>Casemiro</h1>
            </div>
            <div class="team-center container">
                <div class="team" style="background-image: url('img/mu.jpeg');">
                    <div class="img-cover">
                        <img src="img/casemiro.jpeg" alt="Casemiro">
                    </div>
                    <br>
                    <br>
                    
                    <p style="background-color:black;">
                        Carlos Henrique Casimiro (born 23 February 1992), known as Casemiro, is a Brazilian professional footballer who plays as a defensive midfielder for Premier League club Manchester United and captains the Brazil national team. He is known for his defensive abilities, ball-winning skills, and tackling. Casemiro is widely regarded as one of the best defensive midfielders of his generation. He was included in the FIFA FIFPro World XI in 2022.
                        <br>
                        Casemiro began his career with São Paulo and progressed through the ranks. He scored 11 goals in 111 games as a midfielder for the club. His defensive abilities caught the attention of Real Madrid, and he joined the club on loan in January 2013. He played 15 games for Real Madrid Castilla during his loan spell. Afterward, he was signed permanently by Real Madrid for a fee of £5.1 million, becoming a part of their first-team squad at the Santiago Bernabéu.
                        <br>
                        After joining Real Madrid, Casemiro initially struggled to break into the first team. He was loaned to FC Porto for €15 million in order to gain more playing time. During his time at Porto, Casemiro performed impressively and helped the team reach the Champions League quarterfinals. Real Madrid decided to reacquire him for €7.00m in the summer transfers of the 2015 season. Since then, Casemiro has played a crucial role in Real Madrid's success, contributing to their triumphs in various competitions. He has won numerous trophies, including three La Liga titles, three Supercopa de España, three FIFA Club World Cups, three UEFA Super Cup, one Copa del Rey, and five UEFA Champions Leagues. In 2022, after winning his fifth Champions League title at Madrid he later joined to Manchester United for a transfer fee €70.65m. He won the EFL Cup in his first season there.
                        <br>
                        A full international since 2011, Casemiro was in Brazil's squad at the 2018 and 2022 FIFA World Cups, as well as four Copa América tournaments, winning the 2019 Copa América and the runners-up of the 2021 edition.
                    </p>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        
                    </div>
                </div>
                
            </div>
        </section>
        
       
    </body>
    <script src="js/script.js"></script>
    
</html>