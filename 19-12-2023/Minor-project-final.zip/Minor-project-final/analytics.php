<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <title> Analytics</title>
    </head>
    <body>
    <header class="header" id="home" style=" height: 100px; width: 100%;">
            <div class="nav">
                <div class="navigation container">
                    <div class="logo">
                     <a href="index.php"><h1>BallorTalk</h1></a>
                    </div>
                    <div class="menu">
                        <div class="top-nav">
                            <div class="logo">
                                <h1>BallorTalk</h1>
                            </div>
                            <div class="close">
                                <i class="fa fa-times"></i>
                            </div>
                        </div>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Team</a>
                            </li>
                            <li class="nav-item">
                                <a href="news.php" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="players.php" class="nav-link">Famous Players</a>
                            </li>
                            <li class="nav-item">
                                <a href="tribute.php" class="nav-link">Tribute</a>
                            </li>
                            <li class="nav-item">

                                <a href="index.php" class="nav-link">Contact</a>
                            </li>
                           
                            
                        </ul>
                    </div>
                   
                </div>
            </div>
            <!-- <img src="img/3.png" alt=""> -->
            <!-- <div class="row">
                <div class="col">
                    <img src="img/1.png" alt="">
                </div>
                <div class="col">
                    <img src="img/famous_players_quote.png" alt="">
                </div>
            </div> -->
           

            
           
        </header>

        
            

        <section class="section them"  id="teams">
            <div class="title">
                <h1>Analytics of Different Players</h1>
            </div>
            <div class="team-center container">
                <div class="team" style="background-image: url('img/football.jpeg');">
                   
                    
                    <p style="background-color:blue; font-size: large; font-weight:bold;">
                    1. Lionel Messi
                    <br>
                    <br>
                    <img src="img/messistats.jpg">
                    
                    <br>
                    <br>
                    <img src="img/messigraph.png">
                    <br>
                    <br>
                    2. Cristiano Ronaldo
                    <br>
                    <br>
                    <img src="img/ronaldostats.jpg">
                    
                    <br>
                    <br>
                    <br>
                    <img src="img/ronaldograph.jpg">
                    <br>
                    <br>
                    3. Erling Haaland
                    <br>
                    <br>
                    <img src="img/haalandstats.jpg">
                    <br>
                    <img src="img/haalandgraph.jpeg">
                    <br>
                    <br>
                    4. Heung min Son
                    <br>
                    <br>
                    <img src="img/sonstats.jpg">
                    <br>
                    <br>
                    <img src="img/songraph.png">
                    <br>
                    <br>
                    5. Robert Lewandowski
                    <br>
                    <br>
                    Robert Lewandowski is widely regarded as one of the top strikers in the world. He has consistently displayed excellent goal-scoring prowess and is a crucial player for both Bayern Munich and the Polish national team. His performance can be influenced by factors such as the team's tactics, the quality of opponents, and his own physical condition.
                    <br>
                    <br>


                    </p>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        
                    </div>
                </div>
                
            </div>
        </section>
        
       
    </body>
    <script src="js/script.js"></script>
    
</html>