<!DOCTYPE html>
<html lang="en">


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       
        <link rel="stylesheet" href="css/style.css" >
        <link rel="stylesheet" href="font-awesome/css/font-awesome.css">
        <title>Famous Players</title>
    </head>
    <body>
    <header class="header" id="home" style=" height: 100px; width: 100%;">
            <div class="nav">
                <div class="navigation container">
                    <div class="logo">
                     <a href="index.php"><h1>BallorTalk</h1></a>
                    </div>
                    <div class="menu">
                        <div class="top-nav">
                            <div class="logo">
                                <h1>BallorTalk</h1>
                            </div>
                            <div class="close">
                                <i class="fa fa-times"></i>
                            </div>
                        </div>
                        <ul class="nav-list">
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">About</a>
                            </li>
                            <li class="nav-item">
                                <a href="index.php" class="nav-link">Team</a>
                            </li>
                            <li class="nav-item">
                                <a href="news.php" class="nav-link">News</a>
                            </li>
                            <li class="nav-item">
                                <a href="players.php" class="nav-link">Famous Players</a>
                            </li>
                            <li class="nav-item">
                                <a href="tribute.php" class="nav-link">Tribute</a>
                            </li>
                            <li class="nav-item">

                                <a href="index.php" class="nav-link">Contact</a>
                            </li>
                           
                            <li class="nav-item">
                                <a href="/Minor-project-final/login.php" class="nav-link">Log in</a>
                            </li>
                        </ul>
                    </div>
                   
                </div>
            </div>
            <!-- <img src="img/3.png" alt=""> -->
            <!-- <div class="row">
                <div class="col">
                    <img src="img/1.png" alt="">
                </div>
                <div class="col">
                    <img src="img/famous_players_quote.png" alt="">
                </div>
            </div> -->
           

            
           
        </header>

        
            

        <section class="section them"  id="teams">
            <div class="title">
                <h1>Alisson</h1>
            </div>
            <div class="team-center container">
                <div class="team" style="background-image: url('img/liverpool.png');">
                    <div class="img-cover">
                        <img src="img/alisson.jpeg" alt="Alisson">
                    </div>
                    
                    <p style="background-color:black;">
                    Álisson Ramsés Becker (born 2 October 1992), known as Alisson Becker or simply Alisson, is a Brazilian professional footballer who plays as a goalkeeper for Premier League club Liverpool and the Brazil national team. Regarded as one of the best goalkeepers in the world, he is renowned for his immense shot stopping, distribution and ability in one-on-one situations.
                    <br>
                    <br>
                    Alisson joined Internacional's academy in 2002, progressing through the youth set up before making his senior debut in 2013. During his four years with Internacional's senior side, Alisson won the Campeonato Gaúcho title in each season.[10] He signed for Roma in July 2016 and was awarded Serie A Goalkeeper of the Year in 2017–18.[11] In July 2018, Liverpool signed Alisson for a fee of £66.8 million (€72.5 million), making him the most expensive goalkeeper of all time. At Liverpool, Alisson has won the Premier League, FA Cup, EFL Cup, UEFA Champions League and FIFA Club World Cup. In 2019, he was named The Best FIFA Goalkeeper and was also the recipient of the inaugural Yashin Trophy.[12] Alisson has twice been selected in the FIFA FIFPRO Men's World 11.
                    <br>
                    <br>
                    Alisson represented Brazil at various youth levels before making his senior international debut in 2015. He represented the nation at the FIFA World Cup in 2018 and 2022, and the Copa América in 2016, 2019 and 2021, winning the 2019 tournament while also being named its best goalkeeper.[13]
                    </p>
                    <div class="stars">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        
                    </div>
                </div>
                
            </div>
        </section>
        
       
    </body>
    <script src="js/script.js"></script>
    
</html>